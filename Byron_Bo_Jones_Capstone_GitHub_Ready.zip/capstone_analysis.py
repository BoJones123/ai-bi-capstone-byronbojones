
import pandas as pd
import matplotlib.pyplot as plt

# Load sales data
sales_data = pd.read_csv('sales_data.csv')

# Top 3 products by total sales
top_products = sales_data.groupby('Product')['Sales'].sum().sort_values(ascending=False).head(3)
print("Top 3 Products by Sales:")
print(top_products)

# Regional sales summary
regional_sales = sales_data.groupby('Region')['Sales'].sum()
print("Regional Sales Summary:")
print(regional_sales)

# Customer segmentation by age group
sales_data['Age_Group'] = pd.cut(sales_data['Customer_Age'], bins=[0, 20, 40, 60, 100],
                                 labels=['0-20', '21-40', '41-60', '60+'])
age_segment = sales_data.groupby('Age_Group')['Sales'].mean()
print("Customer Age Group Sales:")
print(age_segment)

# Visualizations are included in the attached PNG files.
